import java.util.Stack;

/**
 * Class Client, from Sedgewick
 * 
 * @author (WR) 
 * @version (Sept 2015)
 */

public class Client
{
	public static void main(String[] args)
	{
		Stack<Double> stack = new Stack<Double>();
		while(!StdIn.isEmpty())
		{
			String s = StdIn.readString();
			//--------------------------------------------calculating postfix---------
			for(int i=0;i<s.length();i++){//iterate through the string 
				if(s.charAt(i)==('+')){stack.push((stack.pop())+(stack.pop()));continue;}//sum
				if(s.charAt(i)==('-')){stack.push(-stack.pop()+stack.pop());continue;}//for subtraction operands should be swapped
				if(s.charAt(i)==('*')){stack.push(stack.pop()*stack.pop());continue;}//multiplication
				if(s.charAt(i)==('/')){stack.push(1/(stack.pop())*stack.pop());continue;}//for division first one is reversed
				if(s.charAt(i)==('%')){//for modulo we need a temp variable to keep one operand
					double temp=stack.pop();
					stack.push(stack.pop()%temp);continue;
				}
				stack.push((double)(s.charAt(i)-'0'));
			}
			StdOut.print(stack);
		}
		//		        while(!stack.isEmpty())
		//		        {
		//		            String s = stack.pop().toString();
		//		            StdOut.println(s);
		//		        }
	}
}